import requests
import time
import os

# === KONFIGURASI ===
WALLET = open("wallet.txt").read().strip()
POOL_URL = f"https://api.pool.rplant.xyz/miner/{WALLET}"
PAYOUT_URL = f"https://api.pool.rplant.xyz/miner/{WALLET}/payouts"

def clear_screen():
    os.system('clear' if os.name == 'posix' else 'cls')

def get_status():
    try:
        r = requests.get(POOL_URL, timeout=5)
        data = r.json()

        hashrate = data.get("hashrate", 0)
        shares = data.get("shares", {}).get("valid", 0)
        invalid = data.get("shares", {}).get("invalid", 0)
        unpaid = data.get("balance", 0)

        # Data worker
        workers_data = data.get("workers", {})
        workers = []
        for name, info in workers_data.items():
            workers.append({
                "name": name,
                "hashrate": info.get("hashrate", 0)
            })

        return {
            "hashrate": hashrate,
            "shares": shares,
            "invalid": invalid,
            "unpaid": unpaid,
            "workers": workers,
            "total_workers": len(workers)
        }

    except Exception as e:
        return {"error": f"Status Error: {str(e)}"}

def get_paid_total():
    try:
        r = requests.get(PAYOUT_URL, timeout=5)
        data = r.json()
        paid_total = sum(p.get("amount", 0) for p in data)
        return paid_total
    except Exception as e:
        return f"Payout Error: {str(e)}"

def monitor():
    while True:
        clear_screen()
        print("💎 RPlant Miner Pool Monitoring\n")

        status = get_status()
        paid = get_paid_total()

        if "error" in status:
            print(status["error"])
        elif isinstance(paid, str) and paid.startswith("Payout Error"):
            print(paid)
        else:
            print(f"Wallet        : {WALLET}")
            print(f"Total Hashrate: ⚡ {status['hashrate']}")
            print(f"Shares        : ✅ {status['shares']} | ❌ {status['invalid']}")
            print(f"Unpaid        : 🕓 {status['unpaid']}")
            print(f"Paid          : 💸 {paid:.8f}")
            print(f"Workers Active: 👥 {status['total_workers']} (assumed miners)\n")

            print("🧑‍🏭 Worker Detail:")
            for w in status["workers"]:
                print(f"  - {w['name']} | ⚡ {w['hashrate']} H/s")

        print("\nRefresh in 10s... (Ctrl+C to exit)")
        time.sleep(10)

if __name__ == "__main__":
    monitor()