import os
import subprocess
import psutil
import re
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import (
    Updater, CommandHandler, CallbackQueryHandler, CallbackContext,
    MessageHandler, Filters
)

# === KONFIGURASI ===
TOKEN = '8330637928:AAEl4e63EqR7vgGEHlTfWdpvDffZ75avgUM'
ADMIN_CHAT_ID = 736956967
RDP_NAME = "RDP_JEJE1"
MB_SCRIPT = "mbc.py"
LINK_FILE = "joko.txt"
DELETED_LINK_FILE = "linkyangdihapus.txt"
APPS_TO_KILL = ["mbc.py", "mbc_win16.py", "xmrig.exe", "chrome.exe", "python.exe"]
AUTHORIZED_USERS = set()


def safe_reply_text(update, text, parse_mode=None):
    try:
        if update.message:
            update.message.reply_text(text, parse_mode=parse_mode)
        elif update.callback_query and update.callback_query.message:
            update.callback_query.message.reply_text(text, parse_mode=parse_mode)
    except Exception as e:
        print(f"[ERROR reply_text]: {e}")


def is_admin(update: Update):
    return update.effective_user.id == ADMIN_CHAT_ID


def is_logged_in(update: Update):
    return update.effective_user.id in AUTHORIZED_USERS


def get_mbc_process_by_rdp():
    for proc in psutil.process_iter(['pid', 'cmdline']):
        try:
            if proc.info['cmdline'] and RDP_NAME in ' '.join(proc.info['cmdline']):
                if 'mbc.py' in proc.info['cmdline'] or 'mbc_win16.py' in proc.info['cmdline']:
                    return proc.info['pid']
        except Exception:
            continue
    return None


def start_worker(update: Update = None, context: CallbackContext = None, script_name=MB_SCRIPT):
    if update and not is_logged_in(update):
        safe_reply_text(update, "🚫 Silakan login dulu dengan /login")
        return

    existing_pid = get_mbc_process_by_rdp()
    if existing_pid:
        safe_reply_text(update, f"⚠️ Worker sudah aktif di {RDP_NAME}.")
        return

    try:
        subprocess.Popen(['python', os.path.abspath(script_name), RDP_NAME], creationflags=subprocess.CREATE_NEW_CONSOLE)
        safe_reply_text(update, f"✅ Worker <code>{script_name}</code> dijalankan di {RDP_NAME}.", parse_mode="HTML")
    except Exception as e:
        safe_reply_text(update, f"❌ Gagal menjalankan worker: {e}")


def stop_all_activity(update: Update, context: CallbackContext, restart=False):
    if not is_logged_in(update):
        safe_reply_text(update, "🚫 Silakan login dulu.")
        return

    current_pid = os.getpid()

    for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
        try:
            if proc.info['pid'] == current_pid:
                continue
            for target in APPS_TO_KILL:
                if proc.info['name'] and target in proc.info['name']:
                    if proc.info['cmdline'] and 'bot_panel.py' in ' '.join(proc.info['cmdline']):
                        continue
                    proc.kill()
                    break
                elif proc.info['cmdline'] and any(target in part for part in proc.info['cmdline']):
                    if 'bot_panel.py' in ' '.join(proc.info['cmdline']):
                        continue
                    proc.kill()
                    break
        except Exception:
            continue

    safe_reply_text(update, "⏹️ Semua aplikasi ditutup.")
    if restart:
        safe_reply_text(update, "🔁 Restarting RDP...")
        subprocess.call("shutdown /r /t 1", shell=True)


def list_links(update: Update, context: CallbackContext):
    if not is_logged_in(update):
        safe_reply_text(update, "🚫 Silakan login dulu.")
        return

    if os.path.exists(LINK_FILE):
        with open(LINK_FILE, 'r') as f:
            links = f.read().splitlines()
        msg = "\n".join([f"{i+1}. {link}" for i, link in enumerate(links)])
        total = len(links)
        safe_reply_text(update, f"📄 Total Link: {total}\n\n{msg[:4000]}")
    else:
        safe_reply_text(update, f"❌ File {LINK_FILE} tidak ditemukan.")


def add_link(update: Update, context: CallbackContext):
    if not is_logged_in(update):
        safe_reply_text(update, "🚫 Silakan login dulu.")
        return

    if context.args:
        raw_links = ' '.join(context.args).replace(',', '\n')
        link_lines = [l.strip() for l in raw_links.splitlines() if l.strip()]
        
        if len(link_lines) > 1000:
            safe_reply_text(update, "⚠️ Maksimal 1000 link yang bisa ditambahkan sekaligus.")
            return

        valid_links = []
        invalid_links = []
        for link in link_lines:
            if is_valid_url(link):
                valid_links.append(link)
            else:
                invalid_links.append(link)

        if valid_links:
            existing_links = []
            if os.path.exists(LINK_FILE):
                with open(LINK_FILE, 'r') as f:
                    existing_links = f.read().splitlines()

            all_links = existing_links + valid_links

            with open(LINK_FILE, 'w') as f:
                f.write('\n'.join(all_links) + '\n')

            msg = f"✅ {len(valid_links)} link berhasil ditambahkan."
            if invalid_links:
                msg += f"\n⚠️ {len(invalid_links)} link tidak valid:\n" + "\n".join(invalid_links[:10])
            safe_reply_text(update, msg)
        else:
            safe_reply_text(update, "❌ Tidak ada link valid yang ditemukan.")
    else:
        safe_reply_text(update, "⚠️ Format:\n<code>/addlink https://link1 ... https://link1000</code>", parse_mode="HTML")


def delete_all_links(update: Update, context: CallbackContext):
    if not is_logged_in(update):
        safe_reply_text(update, "🚫 Silakan login dulu.")
        return

    if os.path.exists(LINK_FILE):
        with open(LINK_FILE, 'r') as f:
            deleted_links = f.read()

        if deleted_links.strip():
            with open(DELETED_LINK_FILE, 'a') as df:
                df.write(deleted_links.strip() + '\n')

        open(LINK_FILE, 'w').close()
        safe_reply_text(update, f"🗑️ Semua link dihapus dan disimpan ke {DELETED_LINK_FILE}")
    else:
        safe_reply_text(update, f"❌ File {LINK_FILE} tidak ditemukan.")


def show_deleted_links(update: Update, context: CallbackContext):
    if not is_logged_in(update):
        safe_reply_text(update, "🚫 Silakan login dulu.")
        return

    if os.path.exists(DELETED_LINK_FILE):
        with open(DELETED_LINK_FILE, 'r') as f:
            links = f.read().splitlines()
        total = len(links)
        msg = "\n".join([f"{i+1}. {link}" for i, link in enumerate(links)])
        safe_reply_text(update, f"📁 Total Link yang Dihapus: {total}\n\n{msg[:4000]}")
    else:
        safe_reply_text(update, "❌ Belum ada link yang dihapus.")


def is_valid_url(url):
    pattern = re.compile(r'^(https?://)?([a-zA-Z0-9.-]+\.[a-zA-Z]{2,})(/[^\s]*)?$', re.IGNORECASE)
    return re.match(pattern, url) is not None


def login_command(update: Update, context: CallbackContext):
    if update.effective_user.id == ADMIN_CHAT_ID:
        AUTHORIZED_USERS.add(update.effective_user.id)
        safe_reply_text(update, "✅ Login berhasil.")
        send_control_panel(context.bot)
    else:
        safe_reply_text(update, "🚫 ID Anda tidak diizinkan.")


def send_control_panel(bot):
    keyboard = [
        [InlineKeyboardButton("▶️ Start Win 12", callback_data='start_win12')],
        [InlineKeyboardButton("▶️ Start Win 16", callback_data='start_win16')],
        [InlineKeyboardButton("⏸️ Stop", callback_data='stop')],
        [InlineKeyboardButton("❌ Close (Restart RDP)", callback_data='close')],
        [InlineKeyboardButton("📄 Lihat Link", callback_data='listlink')],
        [InlineKeyboardButton("➕ Tambah Link", switch_inline_query_current_chat="/addlink ")],
        [InlineKeyboardButton("🗑️ Hapus Semua Link", callback_data='deleteall')],
        [InlineKeyboardButton("🧾 Total Link Dihapus", callback_data='showdeleted')],
    ]
    bot.send_message(
        chat_id=ADMIN_CHAT_ID,
        text=f"💥 <b>Panel Kontrol Aktif:</b> <code>{RDP_NAME}</code>",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="HTML"
    )


def button_handler(update: Update, context: CallbackContext):
    if not is_logged_in(update):
        update.callback_query.answer("🚫 Silakan login dulu.")
        return

    data = update.callback_query.data
    query = update.callback_query
    query.answer()

    if data == "start_win12":
        start_worker(update, context, script_name="mbc.py")
    elif data == "start_win16":
        start_worker(update, context, script_name="mbc_win16.py")
    elif data == "stop":
        stop_all_activity(update, context)
    elif data == "close":
        stop_all_activity(update, context, restart=True)
    elif data == "listlink":
        list_links(update, context)
    elif data == "deleteall":
        delete_all_links(update, context)
    elif data == "showdeleted":
        show_deleted_links(update, context)


def handle_text(update: Update, context: CallbackContext):
    if not is_logged_in(update):
        safe_reply_text(update, "🚫 Silakan login dulu.")
        return
    safe_reply_text(update, "⚠️ Perintah tidak dikenali.")


def main():
    updater = Updater(TOKEN, use_context=True)
    dp = updater.dispatcher

    dp.add_handler(CommandHandler("login", login_command))
    dp.add_handler(CommandHandler("addlink", add_link))
    dp.add_handler(CommandHandler("listlink", list_links))
    dp.add_handler(CallbackQueryHandler(button_handler))
    dp.add_handler(MessageHandler(Filters.text & ~Filters.command, handle_text))

    print(f"✅ Bot Telegram aktif di RDP: {RDP_NAME}")
    updater.start_polling()
    updater.idle()


if __name__ == "__main__":
    main()
