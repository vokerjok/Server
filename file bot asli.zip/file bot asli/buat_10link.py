import time
import random
import string
import shutil
import os
import pyperclip
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
from selenium.common.exceptions import TimeoutException
from concurrent.futures import ThreadPoolExecutor


def random_name(length=6):
    return ''.join(random.choices(string.ascii_letters, k=length))

def create_driver(profile_id):
    options = webdriver.ChromeOptions()
    options.add_argument("window-size=1000,1000")
    options.add_argument("--force-device-scale-factor=0.65")  # 65% zoom
    options.add_argument("--disable-gpu")
    options.add_argument("--disable-extensions")
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_experimental_option('useAutomationExtension', False)
    options.add_experimental_option('excludeSwitches', ['enable-automation'])

    profile_path = os.path.join(os.getcwd(), f"chrome_profiles/Profile{profile_id}")
    if not os.path.exists(profile_path):
        os.makedirs(profile_path)
    options.add_argument(f"user-data-dir={profile_path}")
    return webdriver.Chrome(options=options), profile_path

def delete_browser_data(profile_id):
    profile_path = os.path.join(os.getcwd(), f"chrome_profiles/Profile{profile_id}")
    if os.path.exists(profile_path):
        shutil.rmtree(profile_path)
        print(f"[INFO] Browser data for Profile {profile_id} deleted.")

def save_to_log(email, password):
    with open("gmail.txt", "a") as log_file:
        log_file.write(f"{email}|{password}\n")

def read_all_accounts(file_path='gmail.txt'):
    with open(file_path, 'r') as file:
        lines = file.read().splitlines()
    return [line.split('|') for line in lines if '|' in line]

def login_and_setup(profile_id, email, password, label=''):
    driver, profile_path = create_driver(profile_id)
    wait = WebDriverWait(driver, 20)

    try:
        # Buka halaman Firebase Studio
        try:
            driver.get("https://firebase.studio")
            time.sleep(5)
            wait.until(EC.element_to_be_clickable((By.XPATH, "/html/body/main/section[1]/header/a"))).click()
            print("[✅] Klik 'Try Firebase Studio'")
            time.sleep(5)
        except:
            print("[SKIP] Step: try firebase studio")

        # LOGIN GMAIL
        try:
            wait.until(EC.presence_of_element_located((By.ID, "identifierId")))
            email_input = driver.find_element(By.ID, "identifierId")
            ActionChains(driver).click(email_input).send_keys(email).send_keys(Keys.ENTER).perform()
            time.sleep(3)
            if "lookup" in driver.current_url:
                raise Exception("Email tidak ditemukan")
        except Exception as e:
            print(f"[❌ ERROR EMAIL] {email} | {e}")
            with open("akun_bermasalah.txt", "a") as f:
                f.write(f"{email}|{password}  # Error email\n")
            return

        # Input Password
        try:
            wait.until(EC.presence_of_element_located((By.NAME, "Passwd")))
            password_input = driver.find_element(By.NAME, "Passwd")
            ActionChains(driver).click(password_input).send_keys(password).send_keys(Keys.ENTER).perform()
            time.sleep(5)
            if "challenge" in driver.current_url:
                raise Exception("Terkena OTP/CAPTCHA/2FA")
        except Exception as e:
            print(f"[❌ ERROR PASSWORD / OTP] {email} | {e}")
            with open("akun_bermasalah.txt", "a") as f:
                f.write(f"{email}|{password}  # Error password/OTP\n")
            return
        
        driver.get("https://studio.firebase.google.com/")
        time.sleep(15)

        # Klik checkbox "I accept"
        try:
            driver.execute_script("document.getElementById('utos-checkbox').click();")
            print("[✅] Klik checkbox 'I accept'")
        except:
            print("[SKIP] Step: 'I accept' tidak ditemukan")

        # Klik tombol Confirm
        try:
            wait.until(EC.element_to_be_clickable((By.XPATH,
                "/html/body/app-root/ui-loader/onboarding-wrapper/single-column-layout/div/div[2]/onboarding-welcome-v2/div/form/div[2]/button/span"))).click()
            print("[✅] Klik tombol 'Confirm'")
            time.sleep(1)
        except:
            print("[SKIP] Step: tombol 'Confirm' tidak ditemukan")
#=======================================================================================#

        # project pertama

        try:
            driver.get("https://studio.firebase.google.com/new/express")
            time.sleep(5)
            input_field = wait.until(EC.presence_of_element_located((By.XPATH,
                "/html/body/app-root/ui-loader/new-template-app/single-column-layout/div/div/form/div[1]/input")))
            app_name = random_name()
            input_field.clear()
            input_field.send_keys(app_name)
            print(f"[✅] Isi nama app: {app_name}")
            input_field.send_keys(Keys.ENTER)
            print("[✅] Klik Confirm PERJECT 1 ")
            time.sleep(1)
        except:
            print("[SKIP] Step: click Confirm (submit app)")
            time.sleep(1)
            

    # membuat project ke 2 
        try:
            driver.get("https://studio.firebase.google.com/new/express")
            input_field = wait.until(EC.presence_of_element_located((By.XPATH,
                "/html/body/app-root/ui-loader/new-template-app/single-column-layout/div/div/form/div[1]/input")))
            app_name = random_name()
            input_field.clear()
            input_field.send_keys(app_name)
            print(f"[✅] Isi nama app: {app_name}")
            input_field.send_keys(Keys.ENTER)
            print("[✅] Klik Confirm PERJECT 2")
            time.sleep(1)
        except:
            print("[SKIP] Step: click Confirm (submit app)")
            time.sleep(1)
            

    # membuat project ke 3 
        try:
            driver.get("https://studio.firebase.google.com/new/express")
            input_field = wait.until(EC.presence_of_element_located((By.XPATH,
                "/html/body/app-root/ui-loader/new-template-app/single-column-layout/div/div/form/div[1]/input")))
            app_name = random_name()
            input_field.clear()
            input_field.send_keys(app_name)
            print(f"[✅] Isi nama app: {app_name}")
            input_field.send_keys(Keys.ENTER)
            print("[✅] Klik Confirm PERJECT 3 ")
            time.sleep(1)
        except:
            print("[SKIP] Step: click Confirm (submit app)")
            time.sleep(1)

#=================================================================#
#=================================================================#

        try:
            driver.get("https://studio.firebase.google.com/")
            time.sleep(5)

                # Click on the "Join" button
            wait.until(EC.element_to_be_clickable((By.XPATH,
                    "/html/body/app-root/ui-loader/firebase-studio-dashboard/idx-app-chrome/div/div[2]/div[1]/div[2]/devprofile-onboarding/div/div/div/div/button"))).click()
            print("[✅] Klik logo Join")
            time.sleep(10)
                
            input_field = wait.until(EC.presence_of_element_located((By.XPATH,
                "/html/body/app-root/wrapper-dialog/single-column-layout/div/div[2]/onboarding-dialog/div/form/div[1]/input")))

            # Click on the input field
            ActionChains(driver).click(input_field).perform()

            # Type 'Indonesia' in the input field using ActionChains
            ActionChains(driver).send_keys("Indonesia").perform()
            print("[✅] Ketik Indonesia")

            # Press TAB to move to the next field
            ActionChains(driver).send_keys(Keys.TAB).perform()
            print("[✅] Tekan TAB")

            # Press 'A' after pressing TAB
            ActionChains(driver).send_keys("A").perform()
            print("[✅] Tekan A")
                
                # Click Continue button to submit the form
            wait.until(EC.element_to_be_clickable((By.XPATH,
                    "//html/body/app-root/wrapper-dialog/single-column-layout/div/div[2]/onboarding-dialog/div/div/div/button[2]/span"))).click()
            print("[✅] Klik Continue")
            time.sleep(5)

        except Exception as e:
                print(f"[ERROR] Exception occurred: {e}")
                print("[SKIP] Step failed")

#=================================================================#

        # membuat project ke 4 
        try:
            driver.get("https://studio.firebase.google.com/new/express")
            input_field = wait.until(EC.presence_of_element_located((By.XPATH,
                "/html/body/app-root/ui-loader/new-template-app/single-column-layout/div/div/form/div[1]/input")))
            app_name = random_name()
            input_field.clear()
            input_field.send_keys(app_name)
            print(f"[✅] Isi nama app: {app_name}")
            input_field.send_keys(Keys.ENTER)
            print("[✅] Klik Confirm PERJECT 4 ")
            time.sleep(1)
        except:
            print("[SKIP] Step: click Confirm (submit app)")
            

    # membuat project ke 5 
        try:
            driver.get("https://studio.firebase.google.com/new/express")
            input_field = wait.until(EC.presence_of_element_located((By.XPATH,
                "/html/body/app-root/ui-loader/new-template-app/single-column-layout/div/div/form/div[1]/input")))
            app_name = random_name()
            input_field.clear()
            input_field.send_keys(app_name)
            print(f"[✅] Isi nama app: {app_name}")
            input_field.send_keys(Keys.ENTER)
            print("[✅] Klik Confirm PERJECT 5 ")
            time.sleep(1)
        except:
            print("[SKIP] Step: click Confirm (submit app)")

    # membuat project ke 6
        try:
            driver.get("https://studio.firebase.google.com/new/express")
            input_field = wait.until(EC.presence_of_element_located((By.XPATH,
                "/html/body/app-root/ui-loader/new-template-app/single-column-layout/div/div/form/div[1]/input")))
            app_name = random_name()
            input_field.clear()
            input_field.send_keys(app_name)
            print(f"[✅] Isi nama app: {app_name}")
            input_field.send_keys(Keys.ENTER)
            print("[✅] Klik Confirm PERJECT 6 ")
            time.sleep(65)

        except:
            print("[SKIP] Step: click Confirm (submit app)")

        # membuat project ke 7 
        try:
            driver.get("https://studio.firebase.google.com/new/express")
            input_field = wait.until(EC.presence_of_element_located((By.XPATH,
                "/html/body/app-root/ui-loader/new-template-app/single-column-layout/div/div/form/div[1]/input")))
            app_name = random_name()
            input_field.clear()
            input_field.send_keys(app_name)
            print(f"[✅] Isi nama app: {app_name}")
            input_field.send_keys(Keys.ENTER)
            print("[✅] Klik Confirm PERJECT 7 ")
            time.sleep(65)
        except:
            print("[SKIP] Step: click Confirm (submit app)")
            
    # membuat project ke 8 
        try:
            driver.get("https://studio.firebase.google.com/new/express")
            input_field = wait.until(EC.presence_of_element_located((By.XPATH,
                "/html/body/app-root/ui-loader/new-template-app/single-column-layout/div/div/form/div[1]/input")))
            app_name = random_name()
            input_field.clear()
            input_field.send_keys(app_name)
            input_field.send_keys(Keys.ENTER)
            print("[✅] Klik Confirm PERJECT 8 ")
            time.sleep(65)
        except:
            print("[SKIP] Step: click Confirm (submit app)")
            
    # membuat project ke 9 
        try:
            driver.get("https://studio.firebase.google.com/new/express")
            input_field = wait.until(EC.presence_of_element_located((By.XPATH,
                "/html/body/app-root/ui-loader/new-template-app/single-column-layout/div/div/form/div[1]/input")))
            app_name = random_name()
            input_field.clear()
            input_field.send_keys(app_name)
            print(f"[✅] Isi nama app: {app_name}")
            input_field.send_keys(Keys.ENTER)
            print("[✅] Klik Confirm PERJECT 9 ")
            time.sleep(65)
        except:
            print("[SKIP] Step: click Confirm (submit app)")
            
    # membuat project ke  10
        try:
            driver.get("https://studio.firebase.google.com/new/express")
            input_field = wait.until(EC.presence_of_element_located((By.XPATH,
                "/html/body/app-root/ui-loader/new-template-app/single-column-layout/div/div/form/div[1]/input")))
            app_name = random_name()
            input_field.clear()
            input_field.send_keys(app_name)
            print(f"[✅] Isi nama app: {app_name}")
        except:
            print("[SKIP] Step: input app name")

        try:
            input_field.send_keys(Keys.ENTER)
            print("[✅] Klik Confirm PERJECT 10 ")
            time.sleep(5)
        except:
            print("[SKIP] Step: click Confirm (submit app)") 

            

        # Jika sudah sampai sini, berarti sukses login!
        with open("akun_berhasil.txt", "a") as f:
            f.write(f"{email}|{password}\n")
        print(f"[✅] Login berhasil untuk: {email}")
        time.sleep(10)  
        
    except Exception as e:
        print(f"[❌ ERROR GLOBAL] {label} {email}: {e}")
        with open("akun_bermasalah.txt", "a") as f:
            f.write(f"{email}|{password}  # Error global\n")
    finally:
        driver.quit()
        time.sleep(1)
        delete_browser_data(profile_id)

# ==== Eksekusi Utama ====
if __name__ == "__main__":
    accounts = read_all_accounts()

    max_parallel = 10  # Jumlah Chrome clone yang dibuka bersamaan
    with ThreadPoolExecutor(max_workers=max_parallel) as executor:
        futures = []
        for index, (email, password) in enumerate(accounts):
            profile_id = index + 1
            futures.append(executor.submit(login_and_setup, profile_id, email, password, f"Akun {profile_id}"))
            time.sleep(10)  # JEDA 15 detik antar peluncuran Chrome

        for future in futures:
            try:
                future.result()
            except Exception as e:
                print(f"[❌] Thread error: {e}")

    print("\n[🏁] Semua akun selesai diproses.")

