import time
import random
import string
import shutil
import os
import pyperclip
import threading
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
from selenium.common.exceptions import TimeoutException


def random_name(length=6):
    return ''.join(random.choices(string.ascii_letters, k=length))


def create_driver(profile_id):
    options = webdriver.ChromeOptions()
    options.add_argument("window-size=1000,1900")
    options.add_argument("--force-device-scale-factor=0.65")
    options.add_argument("--disable-gpu")
    options.add_argument("--disable-extensions")
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_experimental_option('useAutomationExtension', False)
    options.add_experimental_option('excludeSwitches', ['enable-automation'])

    profile_path = os.path.join(os.getcwd(), f"chrome_profiles/Profile{profile_id}")
    if not os.path.exists(profile_path):
        os.makedirs(profile_path)
    options.add_argument(f"user-data-dir={profile_path}")
    return webdriver.Chrome(options=options), profile_path


def delete_browser_data(profile_id):
    profile_path = os.path.join(os.getcwd(), f"chrome_profiles/Profile{profile_id}")
    if os.path.exists(profile_path):
        shutil.rmtree(profile_path)
        print(f"[INFO] Browser data for Profile {profile_id} deleted.")


def save_to_log(email, password):
    with open("gmail.txt", "a") as log_file:
        log_file.write(f"{email}|{password}\n")


def read_all_accounts(file_path='gmail.txt'):
    with open(file_path, 'r') as file:
        lines = file.read().splitlines()
    return [line.split('|') for line in lines if '|' in line]


def login_and_setup(profile_id, email, password, label=''):
    driver, profile_path = create_driver(profile_id)
    wait = WebDriverWait(driver, 20)

    try:
        driver.get("https://firebase.studio")
        time.sleep(5)
        try:
            wait.until(EC.element_to_be_clickable((By.XPATH, "/html/body/main/section[1]/header/a"))).click()
            print("[✅] Klik 'Try Firebase Studio'")
            time.sleep(15)
        except:
            print("[SKIP] Step: try firebase studio")

        # LOGIN GMAIL
        try:
            wait.until(EC.presence_of_element_located((By.ID, "identifierId")))
            email_input = driver.find_element(By.ID, "identifierId")
            ActionChains(driver).click(email_input).send_keys(email).send_keys(Keys.ENTER).perform()
            time.sleep(3)
            if "lookup" in driver.current_url:
                raise Exception("Email tidak ditemukan")
        except Exception as e:
            print(f"[❌ ERROR EMAIL] {email} | {e}")
            with open("akun_bermasalah.txt", "a") as f:
                f.write(f"{email}|{password}  # Error email\n")
            return

        try:
            wait.until(EC.presence_of_element_located((By.NAME, "Passwd")))
            password_input = driver.find_element(By.NAME, "Passwd")
            ActionChains(driver).click(password_input).send_keys(password).send_keys(Keys.ENTER).perform()
            time.sleep(5)
            if "challenge" in driver.current_url:
                raise Exception("Terkena OTP/CAPTCHA/2FA")
        except Exception as e:
            print(f"[❌ ERROR PASSWORD / OTP] {email} | {e}")
            with open("akun_bermasalah.txt", "a") as f:
                f.write(f"{email}|{password}  # Error password/OTP\n")
            return

        driver.get("https://studio.firebase.google.com/")
        time.sleep(5)

        # Cek workspace ke-4
        try:
            wait.until(EC.element_to_be_clickable((By.XPATH, "/html/body/app-root/ui-loader/firebase-studio-dashboard/idx-app-chrome/div/div[2]/div[2]/div/your-workspaces/div[2]/workspace[4]/div/div/button/mat-icon")))
            print("[✅] Titik tiga ditemukan di workspace ke-4, lanjut proses.")
        except TimeoutException:
            print("[⏩] Titik tiga tidak ditemukan di workspace ke-4. Skip akun ini.")
            driver.quit()
            delete_browser_data(profile_id)
            return

        i = 1
        while i <= 10:
            retry = 0
            success = False

            while retry < 2 and not success:
                try:
                    print(f"[🔄] Mulai proses workspace ke-{i}, percobaan ke-{retry + 1}")

                    titik_xpath = f"/html/body/app-root/ui-loader/firebase-studio-dashboard/idx-app-chrome/div/div[2]/div[2]/div/your-workspaces/div[2]/workspace[{i}]/div/div/button/mat-icon"
                    wait.until(EC.element_to_be_clickable((By.XPATH, titik_xpath))).click()
                    print(f"[✅] Klik titik tiga workspace ke-{i}")
                    time.sleep(1)

                    try:
                        share_xpath = "//div[contains(@class, 'cdk-overlay-container')]//button[normalize-space()='Share']"
                        wait.until(EC.element_to_be_clickable((By.XPATH, share_xpath))).click()
                        print(f"[✅] Klik menu Share workspace ke-{i}")
                        time.sleep(1)
                    except TimeoutException:
                        print(f"[⚠️] Tombol Share tidak muncul, mencoba klik Cancel")
                        cancel_xpath = "/html/body/div[6]/div[2]/div/mat-dialog-container/div/div/share-dialog/div/div[3]/button[2]"
                        try:
                            driver.find_element(By.XPATH, cancel_xpath).click()
                            print(f"[↩️] Klik tombol Cancel")
                        except Exception as e_cancel:
                            print(f"[❌] Gagal klik Cancel: {e_cancel}")
                        retry += 1
                        time.sleep(1)
                        continue

                    # Input email
                    add_xpath = "/html/body/div[6]/div[2]/div/mat-dialog-container/div/div/share-dialog/div/div[2]/input"
                    add_input = wait.until(EC.element_to_be_clickable((By.XPATH, add_xpath)))
                    add_input.click()
                    ActionChains(driver).send_keys("aksamirhana@gmail.com").perform()
                    time.sleep(2)
                    ActionChains(driver).send_keys(Keys.ENTER).perform()
                    print(f"[✅] Masukkan email untuk workspace ke-{i}")
                    time.sleep(2)


                    # Klik tombol salin link
                    copy_btn_xpath = "/html/body/div[6]/div[2]/div/mat-dialog-container/div/div/share-dialog/div/div[3]/button[1]"
                    wait.until(EC.element_to_be_clickable((By.XPATH, copy_btn_xpath))).click()
                    time.sleep(1)
                    copied_link = pyperclip.paste()
                    print(f"[✅] Link tersalin: {copied_link}")

                    # Simpan link ke file
                    with open("link.txt", "a") as file:
                        file.write(copied_link + "\n")
                    print(f"[💾] Link disimpan ke link.txt")

                    # Klik tombol Share
                    confirm_xpath = "/html/body/div[6]/div[2]/div/mat-dialog-container/div/div/share-dialog/div/div[3]/div[2]/button/span"
                    wait.until(EC.element_to_be_clickable((By.XPATH, confirm_xpath))).click()
                    print(f"[✅] Klik tombol Share workspace ke-{i}")
                    time.sleep(10)

                    success = True
                    i += 1

                except Exception as e:
                    print(f"[❌] Gagal di workspace ke-{i}, percobaan ke-{retry + 1}: {e}")
                    try:
                        cancel_btn_xpath = "/html/body/div[6]/div[2]/div/mat-dialog-container/div/div/share-dialog/div/div[3]/button[2]"
                        wait.until(EC.element_to_be_clickable((By.XPATH, cancel_btn_xpath))).click()
                        print(f"[✅] Klik tombol cancel")
                    except Exception as cancel_e:
                        print(f"[⚠️] Tidak bisa klik tombol cancel: {cancel_e}")

                    retry += 1
                    time.sleep(2)

            if not success:
                print(f"[🔁] Semua percobaan gagal untuk workspace ke-{i}, me-refresh halaman dan mengulang dari awal.")
                driver.refresh()
                time.sleep(3)
                i = 1

    except Exception as e:
        print(f"[❌ ERROR GLOBAL] {label} {email}: {e}")
        with open("akun_bermasalah.txt", "a") as f:
            f.write(f"{email}|{password}  # Error global\n")
    finally:
        driver.quit()
        time.sleep(1)
        delete_browser_data(profile_id)


def jalankan_akun_dengan_delay(accounts, start_index):
    for offset in range(0, len(accounts), 1):
        i = start_index + offset
        if i < len(accounts):
            email, password = accounts[i]
            print(f"\n[🚀 THREAD-{start_index+1}] Memproses akun {i+1}: {email}")
            login_and_setup(profile_id=i+1, email=email, password=password, label=f"Akun {i+1}")
        time.sleep(25)


if __name__ == "__main__":
    accounts = read_all_accounts()
    threads = []

    for thread_index in range(1):
        t = threading.Thread(target=jalankan_akun_dengan_delay, args=(accounts, thread_index))
        t.start()
        threads.append(t)
        time.sleep(2)

    for t in threads:
        t.join()

    print("\n[🏁] Semua akun selesai diproses.")
