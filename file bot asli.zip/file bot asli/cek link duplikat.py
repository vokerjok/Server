import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Updater, CommandHandler, CallbackQueryHandler, CallbackContext

# === KONFIGURASI ===
TOKEN = '8297673137:AAH3ZkkSVAWeBSdhsGPwokInjdBtGxNbgiI'
ADMIN_ID = 736956967
FILE_LINK = 'joko.txt'
HASIL_FILE = 'hasil.txt'

# === LOGGING ===
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)

# === FUNGSI: Cek duplikat ===
def cek_duplikat():
    try:
        with open(FILE_LINK, 'r') as f:
            links = [line.strip() for line in f if line.strip()]
        duplikat = set()
        unik = set()
        for link in links:
            if link in unik:
                duplikat.add(link)
            else:
                unik.add(link)
        return sorted(list(duplikat))
    except FileNotFoundError:
        return "File joko.txt tidak ditemukan!"

# === FUNGSI: Hapus duplikat, simpan hasil ke hasil.txt ===
def hapus_duplikat_tanpa_asli():
    try:
        with open(FILE_LINK, 'r') as f:
            links = [line.strip() for line in f if line.strip()]
        seen = set()
        hasil = []
        for link in links:
            if link not in seen:
                hasil.append(link)
                seen.add(link)
        with open(HASIL_FILE, 'w') as f:
            for link in hasil:
                f.write(link + '\n')
        return len(links), len(hasil)
    except FileNotFoundError:
        return None

# === /start handler ===
def start(update: Update, context: CallbackContext):
    user_id = update.effective_user.id
    if user_id != ADMIN_ID:
        update.message.reply_text("❌ Kamu tidak punya izin akses.")
        return

    keyboard = [
        [InlineKeyboardButton("🔍 Cek Duplikat", callback_data='cek')],
        [InlineKeyboardButton("🧹 Hapus Duplikat", callback_data='hapus')],
        [InlineKeyboardButton("📂 Lihat Hasil", callback_data='lihat')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    update.message.reply_text("Pilih menu:", reply_markup=reply_markup)

# === Handler tombol callback ===
def button_handler(update: Update, context: CallbackContext):
    query = update.callback_query
    user_id = query.from_user.id
    query.answer()

    if user_id != ADMIN_ID:
        query.edit_message_text("❌ Kamu tidak punya akses.")
        return

    if query.data == 'cek':
        duplikat = cek_duplikat()
        if isinstance(duplikat, str):
            query.edit_message_text(duplikat)
        elif not duplikat:
            query.edit_message_text("✅ Tidak ada duplikat.")
        else:
            msg = f"⚠️ Ditemukan {len(duplikat)} link duplikat:\n\n" + "\n".join(duplikat)
            query.edit_message_text(msg[:4096])  # Max message size

    elif query.data == 'hapus':
        hasil = hapus_duplikat_tanpa_asli()
        if hasil is None:
            query.edit_message_text("❌ File joko.txt tidak ditemukan.")
        else:
            total, unik = hasil
            query.edit_message_text(f"🧹 Duplikat dihapus.\nTotal link awal: {total}\nLink unik disimpan di hasil.txt: {unik}")

    elif query.data == 'lihat':
        try:
            with open(HASIL_FILE, 'r') as f:
                isi = f.read().strip()
            if not isi:
                query.edit_message_text("📂 hasil.txt kosong.")
            else:
                query.edit_message_text("📂 Isi hasil.txt:\n\n" + isi[:4096])
        except FileNotFoundError:
            query.edit_message_text("❌ hasil.txt belum dibuat.")

# === Fungsi utama ===
def main():
    updater = Updater(TOKEN, use_context=True)
    dp = updater.dispatcher

    dp.add_handler(CommandHandler("start", start))
    dp.add_handler(CallbackQueryHandler(button_handler))

    updater.start_polling()
    updater.idle()

if __name__ == '__main__':
    main()
