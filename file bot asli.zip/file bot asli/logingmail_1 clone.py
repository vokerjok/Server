import os
import time
import random
import string
import shutil
import pyperclip
import requests

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
from selenium.common.exceptions import TimeoutException

# ===== KONFIG TELEGRAM =====
TELEGRAM_TOKEN = "8333206393:AAG8Z76SSbgAEAC1a3oPT8XhAF9t_rDOq3A"  # Ganti dengan token bot kamu
CHAT_ID = 736956967  # Ganti dengan chat ID kamu

# ===== UTILITY =====
def send_telegram_message(message):
    try:
        url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
        payload = {"chat_id": CHAT_ID, "text": message}
        requests.post(url, data=payload)
    except Exception as e:
        print(f"[❌] Gagal kirim notifikasi ke Telegram: {e}")

def random_name(length=6):
    return ''.join(random.choices(string.ascii_letters, k=length))

def create_driver(profile_id):
    options = webdriver.ChromeOptions()

    profile_path = os.path.join("C:\\Users\\Administrator\\Desktop\\chrome_profiles", f"Profile{profile_id}")
    os.makedirs(profile_path, exist_ok=True)
    options.add_argument(f"user-data-dir={profile_path}")
    options.add_argument(f"--profile-directory=Profile {profile_id}")

    # Tampilan Chrome kecil dan ringan
    options.add_argument("--window-size=1000,1000")
    options.add_argument("--force-device-scale-factor=0.65")
    options.add_argument("--disable-gpu")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--disable-extensions")
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_experimental_option('useAutomationExtension', False)
    options.add_experimental_option('excludeSwitches', ['enable-automation'])

    return webdriver.Chrome(options=options), profile_path

def delete_browser_data(profile_id):
    profile_path = os.path.join("C:\\Users\\Administrator\\Desktop\\chrome_profiles", f"Profile{profile_id}")
    if os.path.exists(profile_path):
        shutil.rmtree(profile_path)
        print(f"[INFO] Browser data untuk Profile {profile_id} telah dihapus.")

def save_to_log(email, password):
    with open("gmail.txt", "a") as log_file:
        log_file.write(f"{email}|{password}\n")

def read_all_accounts(file_path='gmail.txt'):
    if not os.path.exists(file_path):
        return []
    with open(file_path, 'r') as file:
        return [line.strip().split('|') for line in file if '|' in line]

# ===== FUNGSI LOGIN GMAIL =====
def login_and_setup(profile_id, email, password):
    driver, profile_path = create_driver(profile_id)
    wait = WebDriverWait(driver, 20)

    try:
        # STEP 1: Buka Firebase Studio
        try:
            driver.get("https://firebase.studio")
            time.sleep(5)
            wait.until(EC.element_to_be_clickable((By.XPATH, "/html/body/main/section[1]/header/a"))).click()
            print("[✅] Klik 'Try Firebase Studio'")
            time.sleep(15)
        except Exception:
            print("[SKIP] Tidak bisa klik Firebase Studio")

        # STEP 2: Masukkan Email
        try:
            wait.until(EC.presence_of_element_located((By.ID, "identifierId")))
            email_input = driver.find_element(By.ID, "identifierId")
            ActionChains(driver).click(email_input).send_keys(email).send_keys(Keys.ENTER).perform()
            time.sleep(3)

            if "lookup" in driver.current_url:
                raise Exception("Email tidak ditemukan")
        except Exception as e:
            print(f"[❌ ERROR EMAIL] {email} | {e}")
            with open("akun_bermasalah.txt", "a") as f:
                f.write(f"{email}|{password}  # Error email\n")
            return

        # STEP 3: Masukkan Password
        try:
            wait.until(EC.presence_of_element_located((By.NAME, "Passwd")))
            password_input = driver.find_element(By.NAME, "Passwd")
            ActionChains(driver).click(password_input).send_keys(password).send_keys(Keys.ENTER).perform()
            time.sleep(5)

            if "challenge" in driver.current_url:
                raise Exception("Terkena OTP/CAPTCHA/2FA")
        except Exception as e:
            print(f"[❌ ERROR PASSWORD / OTP] {email} | {e}")
            with open("akun_bermasalah.txt", "a") as f:
                f.write(f"{email}|{password}  # Error password/OTP\n")
            return

        # Jika berhasil login
        print(f"[✅ LOGIN] {email} berhasil login pada profile {profile_id}")
        send_telegram_message(f"[✅ LOGIN] {email} berhasil login pada profile {profile_id}")

    finally:
        driver.quit()
        print(f"[INFO] Chrome ditutup untuk profile {profile_id}")

# ===== EKSEKUSI =====
if __name__ == "__main__":
    accounts = read_all_accounts()
    for i, (email, password) in enumerate(accounts, start=1):
        print(f"[🔄] Login akun ke-{i}: {email}")
        login_and_setup(profile_id=i, email=email, password=password)
        time.sleep(10)
